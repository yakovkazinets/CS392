#ifndef __CLIENTSERVER__
#define __CLIENTSERVER__

#define BUFLEN 128

/* Echo protocol usually runs on port 7, but requires sudo to start up. */
#define PORT   12345

#endif /* __CLIENTSERVER__ */
