#ifndef SORTS_H_
#define SORTS_H_


/*Function Prototypes!
All that is needed for headers
*/
void insertion_sort(int *array, const int length);

void display_array(int *array, const int length);

#endif