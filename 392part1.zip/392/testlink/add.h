#ifndef ADD_H_
#define ADD_H_

int add_ints(int x, int y);
double add_doubles(double x, double y);

#endif