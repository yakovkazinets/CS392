#include "add.h"

int add_ints(int x, int y){
    return x+y;
}

double add_doubles(double x, double y){
    return x+y;
}
