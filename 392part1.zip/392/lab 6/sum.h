#ifndef SUM_H_
#define SUM_H_
/*
Yakov Kazinets and Tae Kim
I pledge my honor that I have abided by the Stevens Honor System.

*/
/* Function prototype */
int sum_array(int *array, const int length);

#endif
