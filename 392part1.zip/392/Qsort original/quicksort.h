/*******************************************************************************
 * Name        : quicksort.h
 * Author      : Yakov Kazinets
 * Date        : 2/20/2020
 * Description : Quicksort header.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
/**
 * TODO - put all non-static function prototypes from quicksort.c inside
 * wrapper #ifndef.
 */
